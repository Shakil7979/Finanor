<?php $__env->startSection('title', 'Activities'); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2>Activities</h2>
        <div class="box mt-3">
            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box__section row">
                    <div class="row__column row__column--compact mr-2" style="width: 25px;">
                        <?php if($activity->user): ?>
                            <img class="avatar" src="<?php echo e($activity->user->avatar); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="row__column row__column--middle"><?php echo e(__('activities.' . $activity->action)); ?> #<?php echo e($activity->entity_id); ?></div>
                    <div class="row__column row__column--middle row__column--compact"><?php echo e($activity->created_at->diffForHumans()); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/activities/index.blade.php ENDPATH**/ ?>