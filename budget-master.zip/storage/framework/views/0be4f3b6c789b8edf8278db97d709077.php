<?php $__env->startSection('title', __('models.budgets')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <div class="row">
            <div class="row__column row__column--middle">
                <h2><?php echo e(__('models.budgets')); ?></h2>
            </div>
            <div class="row__column row__column--compact row__column--middle">
                <a href="<?php echo e(route('budgets.create')); ?>" class="button"><?php echo e(__('actions.create')); ?> <?php echo e(__('models.budget')); ?></a>
            </div>
        </div>
        <div class="box mt-3">
            <?php if(!count($budgets)): ?>
                <div class="box__section text-center"><?php echo e(__('general.empty_state', ['resource' => strtolower(__('models.budgets'))])); ?></div>
            <?php endif; ?>
            <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($budget->spent); ?>

                <div class="box__section">
                    <div v-pre><?php echo e($budget->tag->name); ?></div>
                    <progress class="mt-2 mb-1" value="<?php echo e($budget->spent); ?>" min="0" max="<?php echo e($budget->amount); ?>"></progress>
                    <div style="font-size: 14px; font-weight: 600;"><?php echo $currency; ?> <?php echo e($budget->formatted_spent); ?> <?php echo e(__('general.of')); ?> <?php echo $currency; ?> <?php echo e($budget->formatted_amount); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/budgets/index.blade.php ENDPATH**/ ?>