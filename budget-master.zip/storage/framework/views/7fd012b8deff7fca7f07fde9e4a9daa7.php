<?php $__env->startSection('settings_title'); ?>
    <h2 class="mb-3"><?php echo e(__('general.dashboard')); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body_formless'); ?>
    <div class="mb-2">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('widget-wizard', [])->html();
} elseif ($_instance->childHasBeenRendered('o1rmSae')) {
    $componentId = $_instance->getRenderedChildComponentId('o1rmSae');
    $componentTag = $_instance->getRenderedChildComponentTagName('o1rmSae');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o1rmSae');
} else {
    $response = \Livewire\Livewire::mount('widget-wizard', []);
    $html = $response->html();
    $_instance->logRenderedChild('o1rmSae', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('widget-list', [])->html();
} elseif ($_instance->childHasBeenRendered('YPKIbio')) {
    $componentId = $_instance->getRenderedChildComponentId('YPKIbio');
    $componentTag = $_instance->getRenderedChildComponentTagName('YPKIbio');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YPKIbio');
} else {
    $response = \Livewire\Livewire::mount('widget-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('YPKIbio', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/settings/dashboard.blade.php ENDPATH**/ ?>