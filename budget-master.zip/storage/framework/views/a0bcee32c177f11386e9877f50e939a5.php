<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2><?php echo e(__('general.dashboard')); ?></h2>
        <p class="mt-1"><?php echo e(__('calendar.months.' . $month)); ?> <?php echo e(date('Y')); ?></p>
        <div class="row row--gutter row--responsive my-3">
            <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row__column">
                    <?php echo $widget->render(); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(count($mostExpensiveTags)): ?>
            <div class="box mt-3">
                <div class="box__section box__section--header">Most Expensive <?php echo e(__('models.tags')); ?></div>
                <?php $__currentLoopData = $mostExpensiveTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box__section row row--seperate">
                        <div class="row__column row__column--middle color-dark">
                            <?php echo $__env->make('partials.tag', ['payload' => $tag], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="row__column row__column--middle">
                            <progress max="<?php echo e($totalSpent); ?>" value="<?php echo e($tag->amount); ?>"></progress>
                        </div>
                        <div class="row__column row__column--middle text-right"><?php echo $currency; ?> <?php echo e(\App\Helper::formatNumber($tag->amount / 100)); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="box mt-3">
            <div class="box__section box__section--header">Daily Balance</div>
            <div class="box__section">
                <div class="ct-chart ct-major-twelfth"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        
        console.log(<?php echo json_encode($dailyBalance); ?>);
console.log(<?php echo json_encode(range(1, $daysInMonth)); ?>);

        document.addEventListener('DOMContentLoaded', function () {
    new Chartist.Line('.ct-chart', {
        labels: <?php echo json_encode(range(1, $daysInMonth)); ?>,
        series: [<?php echo json_encode($dailyBalance); ?>]
    }, {
        showPoint: false,
        lineSmooth: false,
        axisX: { showGrid: false },
        axisY: {
            labelInterpolationFnc: function (value) {
                return value.toFixed(2);
            }
        }
    });
});

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/dashboard.blade.php ENDPATH**/ ?>