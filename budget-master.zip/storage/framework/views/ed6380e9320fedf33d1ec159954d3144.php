<?php $__env->startSection('title', __('models.transactions')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <div class="row mb-3">
            <div class="row__column row__column--middle">
                <h2><?php echo e(__('models.transactions')); ?></h2>
            </div>
            <div class="row__column row__column--compact row__column--middle">
                <a href="<?php echo e(route('transactions.create')); ?>" class="button"><?php echo e(__('actions.create')); ?> <?php echo e(__('models.transactions')); ?></a>
            </div>
        </div>
        <div class="row row--responsive">
            <div class="row__column mr-3" style="max-width: 300px;">
                <div class="box">
                    <div class="box__section">
                        <div class="mb-2">
                            <a href="<?php echo e(route('transactions.index')); ?>">Reset</a>
                        </div>
                        <span>Filter by Tag</span>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mt-1 ml-1">
                                <a href="<?php echo e(route('transactions.index', ['filterBy' => 'tag-' . $tag->id])); ?>" v-pre><?php echo e($tag->name); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row__column">
                <?php if($yearMonths): ?>
                    <?php $__currentLoopData = $yearMonths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h2 class="<?php echo e(key($yearMonths) != $key ? 'mt-3' : ''); ?> mb-2"><?php echo e(__('calendar.months.' . ltrim(explode('-', $key)[1], 0))); ?>, <?php echo e(explode('-', $key)[0]); ?></h2>
                        <div class="box">
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="box__section row row--responsive">
                                    <div class="row__column row__column--middle row row--middle">
                                        <div v-pre><?php echo e($transaction->description); ?></div>
                                        <a href="<?php echo e(route((get_class($transaction) === 'App\Models\Earning' ? 'earnings' : 'spendings') . '.show', [$transaction->id])); ?>">
                                            <i class="fas fa-info-circle fa-xs c-light ml-1"></i>
                                        </a>
                                        <a href="<?php echo e(route((get_class($transaction) === 'App\Models\Earning' ? 'earnings' : 'spendings') . '.edit', [$transaction->id])); ?>">
                                            <i class="fas fa-pencil fa-xs c-light ml-1"></i>
                                        </a>
                                        <form action="<?php echo e(route((get_class($transaction) === 'App\Models\Earning' ? 'earnings' : 'spendings') . '.destroy', [$transaction->id])); ?>" method="POST">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button class="button link">
                                                <i class="fas fa-trash fa-xs c-light ml-1"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="row__column">
                                        <?php if($transaction->tag): ?>
                                            <div class="row">
                                                <div class="row__column row__column--compact row__column--middle mr-05" style="font-size: 12px;">
                                                    <i class="fas fa-tag" style="color: #<?php echo e($transaction->tag->color); ?>;"></i>
                                                </div>
                                                <div class="row__column row__column--compact row__column--middle" v-pre><?php echo e($transaction->tag->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row__column row__column--compact w-50">
                                        <?php if($transaction->recurring_id): ?>
                                            <i class="fas fa-recycle"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row__column row__column--compact row__column--middle w-150 row row--middle row--right <?php echo e(get_class($transaction) == 'App\Models\Earning' ? 'color-green' : 'color-red'); ?>">
                                        <div class="row__column row__column--compact"><?php echo $currency; ?> <?php echo e($transaction->formatted_amount); ?></div>
                                        <div class="row__column row__column--compact ml-1">
                                            <?php if(get_class($transaction) == 'App\Models\Earning'): ?>
                                                <i class="fas fa-arrow-alt-left fa-sm"></i>
                                            <?php else: ?>
                                                <i class="fas fa-arrow-alt-right fa-sm"></i>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="box">
                        <?php echo $__env->make('partials.empty_state', ['payload' => 'transactions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/transactions/index.blade.php ENDPATH**/ ?>