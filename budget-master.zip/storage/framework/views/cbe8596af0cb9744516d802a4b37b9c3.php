<?php $__env->startSection('settings_title'); ?>
    <h2 class="mb-3"><?php echo e(__('general.account')); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body'); ?>
    <div class="box">
        <div class="box__section">
            <div class="input input--small">
                <label><?php echo e(__('fields.email')); ?></label>
                <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" />
            </div>
            <div class="row">
                <div class="row__column input">
                    <label><?php echo e(__('fields.password')); ?></label>
                    <input type="password" name="password" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="row__column input ml-2">
                    <label><?php echo e(__('actions.verify')); ?> <?php echo e(__('fields.password')); ?></label>
                    <input type="password" name="password_confirmation" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'password_confirmation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <button class="button"><?php echo e(__('actions.save')); ?></button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/settings/account.blade.php ENDPATH**/ ?>