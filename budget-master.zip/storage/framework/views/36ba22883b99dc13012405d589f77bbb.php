<?php $__currentLoopData = $errors->get($payload); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="text-red-500 text-sm mt-1"><?php echo e($error); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/partials/validation_error.blade.php ENDPATH**/ ?>