<?php $__env->startSection('title', __('models.tags')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <div class="row mb-3">
            <div class="row__column row__column--middle">
                <h2><?php echo e(__('models.tags')); ?></h2>
            </div>
            <div class="row__column row__column--compact row__column--middle">
                <a href="<?php echo e(route('tags.create')); ?>" class="button"><?php echo e(__('actions.create')); ?> <?php echo e(__('models.tag')); ?></a>
            </div>
        </div>
        <div class="box">
            <?php if(count($tags)): ?>
                <div class="box__section box__section--header row">
                    <div class="row__column row__column--compact mr-2" style="width: 20px;"></div>
                    <div class="row__column"><?php echo e(__('fields.name')); ?></div>
                    <div class="row__column row__column--double" style="flex: 2;"><?php echo e(__('models.spendings')); ?></div>
                </div>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box__section row">
                        <div class="row__column row__column--compact row__column--middle mr-2">
                            <div style="width: 15px; height: 15px; border-radius: 2px; background: #<?php echo e($tag->color); ?>;"></div>
                        </div>
                        <div class="row__column row__column--middle" v-pre><?php echo e($tag->name); ?></div>
                        <div class="row__column row__column--middle"><?php echo e($tag->spendings->count()); ?></div>
                        <div class="row__column row__column--middle row row--right">
                            <div class="row__column row__column--compact">
                                <a href="<?php echo e(route('tags.edit', ['tag' => $tag->id])); ?>">
                                    <i class="fas fa-pencil"></i>
                                </a>
                            </div>
                            <div class="row__column row__column--compact ml-2">
                                <?php if($tag->budgets->count() || $tag->spendings->count()): ?>
                                    <i class="fas fa-trash-alt"></i>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('tags.destroy', ['tag' => $tag->id])); ?>">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo e(csrf_field()); ?>

                                        <button class="button link">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php echo $__env->make('partials.empty_state', ['payload' => 'tags'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/tags/index.blade.php ENDPATH**/ ?>