<?php $__env->startSection('settings_title'); ?>
    <h2 class="mb-3"><?php echo e(__('general.profile')); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body'); ?>
    <div class="box">
        <div class="box__section">
            <div class="input input--small">
                <label><?php echo e(__('fields.avatar')); ?></label>
                <img src="<?php echo e(Auth::user()->avatar); ?>" style="width: 200px; height: 200px; border-radius: 5px; object-fit: cover;" />
                <input type="file" name="avatar" />
                <?php echo $__env->make('partials.validation_error', ['payload' => 'avatar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="input input--small">
                <label><?php echo app('translator')->get('fields.name'); ?></label>
                <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" />
            </div>
            <button class="button"><?php echo e(__('actions.save')); ?></button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/settings/profile.blade.php ENDPATH**/ ?>