<div class="card card--blue">
    <h2 style="font-size: 20px;"><?php echo $currencySymbol; ?> <?php echo e($balance); ?></h2>
    <div class="mt-1">Balance</div>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/widgets/balance.blade.php ENDPATH**/ ?>