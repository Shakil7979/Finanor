<?php $__env->startSection('title', __('actions.edit') . ' ' . __('models.spending')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2><?php echo e(__('actions.edit')); ?> <?php echo e(__('models.spending')); ?></h2>
        <div class="mt-3 box">
            <form method="POST" action="<?php echo e(route('spendings.update', ['spending' => $spending->id])); ?>" autocomplete="off">
                <?php echo e(method_field('PATCH')); ?>

                <?php echo e(csrf_field()); ?>

                <div class="box__section">
                    <div class="input input--small">
                        <label><?php echo e(__('models.tag')); ?></label>
                        <select name="tag_id">
                            <option value="">-</option>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>" <?php echo e($tag->id === $spending->tag_id ? 'selected' : ''); ?> v-pre><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'tag_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small">
                        <label><?php echo e(__('fields.date')); ?></label>
                        <DatePicker start-date="<?php echo e($spending->happened_on); ?>"></DatePicker>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'date'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small">
                        <label><?php echo e(__('fields.description')); ?></label>
                        <input type="text" name="description" value="<?php echo e($spending->description); ?>" />
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small mb-0">
                        <label><?php echo e(__('fields.amount')); ?></label>
                        <input type="text" name="amount" value="<?php echo e($spending->formatted_amount); ?>" />
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="box__section box__section--highlight row row--right">
                    <div class="row__column row__column--compact row__column--middle">
                        <a href="<?php echo e(route('transactions.index')); ?>"><?php echo e(__('actions.cancel')); ?></a>
                    </div>
                    <div class="row__column row__column--compact ml-2">
                        <button class="button"><?php echo app('translator')->get('actions.save'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/spendings/edit.blade.php ENDPATH**/ ?>