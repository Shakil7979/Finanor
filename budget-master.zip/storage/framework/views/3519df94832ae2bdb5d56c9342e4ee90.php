<?php $__env->startSection('title', __('actions.create') . ' ' . __('models.space')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2 class="mb-3"><?php echo e(__('actions.create')); ?> <?php echo e(__('models.space')); ?></h2>
        <div class="box mt-3">
            <form method="POST" action="<?php echo e(route('spaces.store')); ?>" autocomplete="off">
                <?php echo e(csrf_field()); ?>

                <div class="box__section">
                    <div class="input input--small">
                        <label><?php echo e(__('fields.name')); ?></label>
                        <input type="text" name="name" />
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small mb-0">
                        <label><?php echo e(__('fields.currency')); ?></label>
                        <select name="currency_id">
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'currency_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="box__section box__section--highlight row row--right">
                    <div class="row__column row__column--compact row__column--middle">
                        <a href="<?php echo e(route('settings.spaces.index')); ?>"><?php echo e(__('actions.cancel')); ?></a>
                    </div>
                    <div class="row__column row__column--compact ml-2">
                        <button class="button"><?php echo e(__('actions.create')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/spaces/create.blade.php ENDPATH**/ ?>