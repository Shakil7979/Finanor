<?php $__env->startSection('tailwind', true); ?>

<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('body'); ?>
    <div class="max-w-sm mx-auto my-12">
        <img class="h-12 mx-auto mb-8" src="/logo.svg" />
        <div class="p-5 bg-white border rounded-md">
            <form method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">Name</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="text" name="name" value="<?php echo e(old('name')); ?>" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">E-mail</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="email" name="email" value="<?php echo e(old('email')); ?>" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">Password</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="password" name="password" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">Verify password</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="password" name="password_confirmation" />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'password_confirmation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">Currency</label>
                    <select class="w-full px-3 py-2 text-sm border rounded-md appearance-none" name="currency">
                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?> (<?php echo $currency->symbol; ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'currency'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <button class="w-full py-2.5 hover:bg-primary-dark transition text-sm bg-primary-regular text-white rounded-md">Register</button>
            </form>
        </div>
        <div class="mt-4 text-center">
            <a class="text-sm transition text-primary-regular hover:text-primary-dark" href="<?php echo e(route('login')); ?>">Already using Budget? Log in.</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/register.blade.php ENDPATH**/ ?>