<?php $__env->startSection('title', __('actions.edit') . ' ' . __('models.space')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2 class="mb-3"><?php echo e(__('actions.edit')); ?> <?php echo e(__('models.space')); ?></h2>
        <form method="POST" action="<?php echo e(route('spaces.update', ['space' => $space->id])); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="box">
                <div class="box__section row">
                    <div class="row__column">
                        <h2><?php echo e(__('general.general')); ?></h2>
                    </div>
                    <div class="row__column row__column--double">
                        <div class="input input--small">
                            <label><?php echo e(__('fields.name')); ?></label>
                            <input type="text" name="name" value="<?php echo e($space->name); ?>" />
                        </div>
                        <div class="input input--small mb-0">
                            <label><?php echo e(__('fields.currency')); ?></label>
                            <select disabled>
                                <option><?php echo e($space->currency->name); ?></option>
                            </select>
                            <div class="hint mt-05">You cannot modify the currency anymore</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row row--right mt-2">
                <a class="button button--secondary mr-2" href="<?php echo e(route('settings.spaces.index')); ?>"><?php echo e(__('actions.cancel')); ?></a>
                <button class="button"><?php echo e(__('actions.save')); ?></button>
            </div>
        </form>
        <div class="box mt-3">
            <div class="box__section row">
                <div class="row__column">
                    <h2><?php echo e(__('general.members')); ?></h2>
                </div>
                <div class="row__column row__column--double">
                    <?php $__currentLoopData = $space->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e($i > 0 ? 'mt-2' : null); ?>">
                            <div class="color-dark mb-1" v-pre><?php echo e($user->name); ?></div>
                            <div class="fs-sm"><?php echo e(ucfirst($user->pivot->role)); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="box mt-3">
            <div class="box__section row">
                <div class="row__column">
                    <h2><?php echo e(__('general.invites')); ?></h2>
                </div>
                <div class="row__column row__column--double">
                    <?php if(!count($space->invites)): ?>
                        <span>There aren't any invites</span>
                    <?php endif; ?>
                    <?php $__currentLoopData = $space->invites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e($i > 0 ? 'mt-2' : ''); ?>">
                            <div class="color-dark mb-1" v-pre><?php echo e($invite->invitee->name); ?></div>
                            <div class="fs-sm" v-pre><?php echo e(__('general.invited_by')); ?> <?php echo e($invite->inviter->name); ?> &middot; <?php echo e($invite->status); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="box mt-3">
            <div class="box__section row">
                <div class="row__column">
                    <h2><?php echo e(__('general.invite_someone')); ?></h2>
                </div>
                <div class="row__column row__column--double">
                    <?php if(session('inviteStatus')): ?>
                        <?php switch(session('inviteStatus')):
                            case ('success'): ?>
                                <div class="color-green mb-2">An invite has been sent</div>
                                <?php break; ?>

                            <?php case ('present'): ?>
                                <div class="color-red mb-2">User is already part of space</div>
                                <?php break; ?>

                            <?php case ('exists'): ?>
                                <div class="color-red mb-2">Invite has already been sent</div>
                                <?php break; ?>
                        <?php endswitch; ?>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('spaces.invite', ['space' => $space->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="input input--small">
                            <label><?php echo e(__('fields.email')); ?></label>
                            <input type="email" name="email" />
                            <?php echo $__env->make('partials.validation_error', ['payload' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="input input--small">
                            <label><?php echo e(__('fields.role')); ?></label>
                            <select name="role">
                                <option value="admin">Admin</option>
                                <option value="regular" selected>Regular</option>
                            </select>
                            <?php echo $__env->make('partials.validation_error', ['payload' => 'role'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <button class="button"><?php echo e(__('actions.invite')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/spaces/edit.blade.php ENDPATH**/ ?>