<div class="bg-red-50 border border-red-100 text-red-700 flex py-2 px-4 items-center rounded-md <?php echo e($payload['classes']); ?>">
    <i class="far fa-times fa-sm"></i>
    <div class="flex-1 text-sm font-medium text-center"><?php echo e($payload['message']); ?></div>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/partials/alerts/danger.blade.php ENDPATH**/ ?>