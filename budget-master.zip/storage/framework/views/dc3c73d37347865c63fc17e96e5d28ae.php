<div>
    <?php if($visible): ?>
        <div class="box">
            <div class="box__section">
                <div class="input input--small">
                    <label>Type</label>
                    <select wire:model="selectedType">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>"><?php echo e(ucfirst($type)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if(count($expectedProperties)): ?>
                    <div class="input input--small">
                        <label>Properties</label>
                        <?php $__currentLoopData = $expectedProperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="mb-05"><?php echo e(ucfirst($key)); ?></div>
                                <select wire:model="providedProperties.<?php echo e($key); ?>">
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($y); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $y))); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <button class="button mr-1" wire:click="persist">Create</button>
                    <button class="button button--secondary" wire:click="toggle">Cancel</button>
                </div>
            </div>
        </div>
    <?php else: ?>
        <button wire:click="toggle" class="button">Create</button>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/livewire/widget-wizard.blade.php ENDPATH**/ ?>