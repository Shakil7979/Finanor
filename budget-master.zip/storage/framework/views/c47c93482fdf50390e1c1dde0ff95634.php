<div class="card card--red">
    <h2 style="font-size: 20px;"><?php echo $currencySymbol; ?> <?php echo e($spent); ?></h2>
    <div class="mt-1">Spent <?php echo e($period); ?></div>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/widgets/spent.blade.php ENDPATH**/ ?>