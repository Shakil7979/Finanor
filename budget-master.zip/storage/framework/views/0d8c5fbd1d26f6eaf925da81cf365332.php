<div class="row <?php echo e($payload['classes']); ?>" style="
    padding: 15px;
    color: #FFF;
    background: #AAD26F;
    border-radius: 5px;
">
    <div class="row__column row__column--compact">
        <i class="fas fa-check"></i>
    </div>
    <div class="row__column text-center" style="font-weight: 600;"><?php echo e($payload['message']); ?></div>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/partials/alerts/success.blade.php ENDPATH**/ ?>