<div class="box__section text-center">
    <div class="mb-1"><?php echo e(__('general.empty_state', ['resource' => strtolower(__('models.' . $payload))])); ?></div>
    <a href="<?php echo e(route($payload . '.create')); ?>" style="font-size: 14px;"><?php echo e(__('actions.create')); ?></a>
</div>
<?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/partials/empty_state.blade.php ENDPATH**/ ?>