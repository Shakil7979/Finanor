<?php $__env->startSection('settings_title'); ?>
    <h2><?php echo e(__('models.spaces')); ?></h2>
    <p class="mt-1 mb-3"><?php echo e(__('general.spaces_explanation')); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body'); ?>
    <a class="button mb-2" href="<?php echo e(route('spaces.create')); ?>"><?php echo e(__('actions.create')); ?></a>
    <div class="box">
        <ul class="box__section">
            <?php $__currentLoopData = $spaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $space): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="row row--middle">
                    <div class="row__column" v-pre><?php echo e($space->name); ?> &middot; <?php echo e(ucfirst($space->pivot->role)); ?></div>
                    <div class="row__column row__column--compact">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $space)): ?>
                            <a class="button button--secondary button--small" href="<?php echo e(route('spaces.edit', ['space' => $space->id])); ?>"><?php echo e(__('pages.settings')); ?></a>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/settings/spaces/index.blade.php ENDPATH**/ ?>