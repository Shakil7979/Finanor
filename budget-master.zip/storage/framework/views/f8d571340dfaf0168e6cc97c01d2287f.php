<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2 v-pre><?php echo e($recurring->description); ?></h2>
        <div class="row my-3">
            <div class="row__column row__column--compact">
                <?php if($recurring->status): ?>
                    <span style="border-radius: 5px; background: #D8F9E8; color: #51B07F; padding: 5px 10px; font-size: 14px; font-weight: 600;"><i class="fas fa-check fa-xs"></i> Active</span>
                <?php else: ?>
                    <span style="border-radius: 5px; background: #FFE7EC; color: #F25C68; padding: 5px 10px; font-size: 14px; font-weight: 600;"><i class="fas fa-times fa-xs"></i> Inactive</span>
                <?php endif; ?>
            </div>
            <?php if($recurring->tag): ?>
                <div class="row__column row__column--compact ml-1">
                    <?php echo $__env->make('partials.tag', ['payload' => $recurring->tag], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="color-dark mb-2"><?php echo e(__('models.spendings')); ?></div>
        <div class="box">
            <?php if(count($recurring->spendings)): ?>
                <?php $__currentLoopData = $recurring->spendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box__section">
                        <div>
                            <div class="color-dark"><?php echo e($spending->happened_on); ?></div>
                            <div class="mt-1" style="font-size: 14px; font-weight: 600;"><?php echo e($spending->formatted_happened_on); ?></div>
                        </div>
                        <div></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="box__section text-center">There aren't any spendings (yet)</div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sadbin Shakil\Downloads\budget-master\budget-master\resources\views/recurrings/show.blade.php ENDPATH**/ ?>