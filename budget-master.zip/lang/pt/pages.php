<?php

return [
    'reports' => 'Relatórios',
    'settings' => 'Definições',
    'log_out' => 'Sair'
];
