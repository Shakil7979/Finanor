<?php

return [
    'months' => [
        1 => 'Janeiro',
        2 => 'Fevereiro',
        3 => 'Março',
        4 => 'Abril',
        5 => 'Maio',
        6 => 'Junho',
        7 => 'Julho',
        8 => 'Agosto',
        9 => 'Setembro',
        10 => 'Outubro',
        11 => 'Novembro',
        12 => 'Dezembro'
    ],
    'weekdays' => [
        0 => 'Segunda-feira',
        1 => 'Terça-feira',
        2 => 'Quarta-feira',
        3 => 'Quinta-feira',
        4 => 'Sexta-feira',
        5 => 'Sábado-feira',
        6 => 'Domingo-feira'
    ],
    'intervals' => [
        'yearly' => 'Anual',
        'monthly' => 'Por mês',
        'biweekly' => 'Quinzenal',
        'weekly' => 'Semanal',
        'daily' => 'Diariamente'
    ]
];
