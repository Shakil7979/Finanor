<?php

return [
    'reports' => 'Reportes',
    'settings' => 'Configuración',
    'log_out' => 'Cerrar sesión'
];
