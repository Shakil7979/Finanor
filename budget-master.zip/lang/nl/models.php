<?php

return [
    'budgets' => 'Budgetten',
    'budget' => 'Budget',

    'tags' => 'Etiketten',
    'tag' => 'Etiket',

    'recurrings' => 'Terugkerenden',
    'recurring' => 'Terugkerend',

    'earnings' => 'Inkomsten',
    'earning' => 'Inkomst',

    'spendings' => 'Uitgaven',
    'spending' => 'Uitgave',

    'transactions' => 'Transacties',
    'transaction' => 'Transactie',

    'imports' => 'Imports',
    'import' => 'Import'
];
