<?php

return [
    'reports' => 'Rapporten',
    'settings' => 'Instellingen',
    'log_out' => 'Log Uit'
];
