<?php

return [
    'transaction' => [
        'created' => 'Созданная транзакция',
        'deleted' => 'Удаленная транзакция'
    ],

    'recurring' => [
        'created' => 'Создать повторяющийся',
        'deleted' => 'Удалить повторяющиеся'
    ],

    'tag' => [
        'created' => 'Созданный тег',
        'deleted' => 'Удаленный тег'
    ],

    'import' => [
        'created' => 'Создан импорт',
        'deleted' => 'Удален импорт'
    ]
];
