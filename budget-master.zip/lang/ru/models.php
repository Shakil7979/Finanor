<?php

return [
    'budgets' => 'Бюджеты',
    'budget' => 'Бюджет',

    'spaces' => 'Пространства',
    'space' => 'Пространство',

    'tags' => 'Теги',
    'tag' => 'Тег',

    'recurrings' => 'Повторяющиеся',
    'recurring' => 'Повторяющийся',

    'earnings' => 'Заработок',
    'earning' => 'Заработок',

    'spendings' => 'Расходы',
    'spending' => 'Расходы',

    'transactions' => 'Сделки',
    'transaction' => 'Сделка',

    'imports' => 'Импорт',
    'import' => 'Импорт'
];
