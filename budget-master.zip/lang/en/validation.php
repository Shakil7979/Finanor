<?php

return [
    'required' => 'Can\'t be blank',
    'confirmed' => 'Doesn\'t match',

    'max' => [
        'string' => 'Can\'t be longer than :max characters'
    ],

    'forbidden' => 'Not permitted to use this resource'
];
