<?php

return [
    'default_transaction_type' => 'Standard transaktiontyp',
    'first_day_of_week' => 'Erster tag der woche',

    'period' => 'Zeitraum'
];
