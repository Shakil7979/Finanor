<?php

return [
    'reports' => 'Rapporter',
    'settings' => 'Indstillinger',
    'log_out' => 'Log Ud'
];
