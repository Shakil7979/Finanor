<?php

return [
    'budgets' => 'Budgetter',
    'budget' => 'Budget',

    'tags' => 'Etiket',
    'tag' => 'Etiketter',

    'recurrings' => 'Tilbagevendenden',
    'recurring' => 'Tilbagevendende',

    'earnings' => 'Indkomster',
    'earning' => 'Indkomst',

    'spendings' => 'Udgifter',
    'spending' => 'Udgift',

    'imports' => 'Imports',
    'import' => 'Import'
];
