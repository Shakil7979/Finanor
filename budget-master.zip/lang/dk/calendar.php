<?php

return [
    'months' => [
        1 => 'Januar',
        2 => 'Februar',
        3 => 'Marts',
        4 => 'April',
        5 => 'Maj',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'August',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'December'
    ],
    'weekdays' => [
        0 => 'Mandag',
        1 => 'Tirsdag',
        2 => 'Onsdag',
        3 => 'Torsdag',
        4 => 'Fredag',
        5 => 'Lørdag',
        6 => 'Søndag'
    ],
    'intervals' => [
        'yearly' => 'Årligt',
        'monthly' => 'Månedligt',
        'biweekly' => 'Hver anden uge',
        'weekly' => 'Ugentlig',
        'daily' => 'Dagligt'
    ]
];
