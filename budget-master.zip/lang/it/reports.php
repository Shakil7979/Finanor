<?php

return [
    'weekly_balance' => [
        'title' => 'Bilancio settimanale',
        'description' => 'Bilancio settimanale per anno&mdash;in un grafico.'
    ],

    'most_expensive_tags' => [
        'title' => 'Categorie più dispendiose',
        'description' => 'Catogorie più dispensiose&mdash;scopri cosa costa di più.'
    ]
];
