<?php

namespace App\Exceptions;

use Exception;

class VerificationMailRateLimitException extends Exception
{
    //
}
