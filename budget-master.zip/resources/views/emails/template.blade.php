<!DOCTYPE html>
<html>
    <body style="font-family: Roboto, Arial, Helvetica, sans-serif;">
        <div style="margin: 50px auto; width: 90%; max-width: 700px;">
            @yield('content')
        </div>
    </body>
</html>
