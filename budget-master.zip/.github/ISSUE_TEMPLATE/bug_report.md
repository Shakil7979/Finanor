---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''
---

**Expected behavior**

What should happen?

**Current behavior**

What's happening right now when trying to perform your desired action?

**Steps to reproduce**

1. Go to ABC
2. Click on XYZ
3. Explosions and thunderstorms appear

*If applicable, screenshots can be added here*
