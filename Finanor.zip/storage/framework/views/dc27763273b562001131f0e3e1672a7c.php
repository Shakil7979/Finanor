<?php $__env->startSection('tailwind', true); ?>

<?php $__env->startSection('title', 'Log in'); ?>

<?php $__env->startSection('body'); ?>
    <div class="max-w-sm mx-auto my-12">
        <img class="h-[150px] mx-auto mb-8 sk_logo" src="/logo.png" />
        <?php if(session('alert_type') && session('alert_message')): ?>
            <?php echo $__env->make('partials.alerts.' . session('alert_type'), ['payload' => ['classes' => 'mb-4', 'message' => session('alert_message')]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <div class="p-5 bg-white border rounded-md">
            <form method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">E-mail</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="email" name="email" value="<?php echo e(old('email')); ?>" autofocus />
                </div>
                <div class="mb-5">
                    <label class="block mb-1 text-sm text-gray-700">Password</label>
                    <input class="w-full px-3 py-2 text-sm border rounded-md" type="password" name="password" />
                    <div class="mt-1 text-right">
                        <a href="<?php echo e(route('reset_password')); ?>" class="text-sm transition text-primary-regular hover:text-primary-dark">Forgot your password?</a>
                    </div>
                </div>
                <button class="w-full py-2.5 hover:bg-primary-dark transition text-sm bg-primary-regular text-white rounded-md">Log in</button>
            </form>
        </div>
        <div class="mt-4 text-center">
            <a class="text-sm transition text-primary-regular hover:text-primary-dark" href="<?php echo e(route('register')); ?>">First time here? Register.</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/login.blade.php ENDPATH**/ ?>