<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <div class="row row--responsive">
            <div class="row__column mr-3" style="max-width: 300px;">
                <div class="box">
                    <div class="box__section box__section--header"><?php echo e(__('pages.settings')); ?></div>
                    <ul class="box__section">
                        <li><a href="<?php echo e(route('settings.profile')); ?>"><i class="fas fa-user fa-sm"></i> <?php echo e(__('general.profile')); ?></a></li>
                        <li><a href="<?php echo e(route('settings.account')); ?>"><i class="fas fa-lock fa-sm"></i> <?php echo e(__('general.account')); ?></a></li>
                        
                        <li><a href="<?php echo e(route('settings.preferences')); ?>"><i class="fas fa-sliders-h fa-sm"></i> <?php echo e(__('general.preferences')); ?></a></li>
                        <li><a href="<?php echo e(route('settings.dashboard')); ?>"><i class="fas fa-home fa-sm"></i> <?php echo e(__('general.dashboard')); ?></a></li>
                        
                        <li><a href="<?php echo e(route('settings.spaces.index')); ?>"><i class="fas fa-rocket fa-sm"></i> <?php echo e(__('models.spaces')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="row__column">
                <?php echo $__env->yieldContent('settings_title'); ?>
                <form method="POST" action="<?php echo e(route('settings.store')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo $__env->yieldContent('settings_body'); ?>
                </form>
                <?php echo $__env->yieldContent('settings_body_formless'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/settings/layout.blade.php ENDPATH**/ ?>