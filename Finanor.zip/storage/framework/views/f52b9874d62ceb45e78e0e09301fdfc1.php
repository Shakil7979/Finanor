<?php $__env->startSection('title', __('actions.create') . ' ' . __('models.tag')); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2><?php echo e(__('actions.create')); ?> <?php echo e(__('models.tag')); ?></h2>
        <div class="mt-3 box">
            <form method="POST" action="<?php echo e(route('tags.store')); ?>" autocomplete="off">
                <?php echo e(csrf_field()); ?>

                <div class="box__section">
                    <div class="input input--small">
                        <label><?php echo e(__('fields.name')); ?></label>
                        <input type="text" name="name" />
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small mb-0">
                        <label><?php echo e(__('fields.color')); ?></label>
                        <color-picker></color-picker>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'color'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="box__section box__section--highlight row row--right">
                    <div class="row__column row__column--compact row__column--middle">
                        <a href="<?php echo e(route('tags.index')); ?>"><?php echo e(__('actions.cancel')); ?></a>
                    </div>
                    <div class="row__column row__column--compact ml-2">
                        <button class="button"><?php echo e(__('actions.create')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/tags/create.blade.php ENDPATH**/ ?>