<div class="box">
    <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div wire:key="<?php echo e($widget->id); ?>" class="box__section row">
            <div class="row__column row__column--compact mr-1">
                #<?php echo e($widget->sorting_index + 1); ?>

            </div>
            <div class="row__column">
                <?php echo e(ucfirst($widget->type)); ?>

                <?php if(count((array) $widget->properties)): ?>
                    (<?php echo e(ucfirst(str_replace('_', ' ', $widget->properties->{key($widget->properties)}))); ?>)
                <?php endif; ?>
            </div>
            <div class="row__column">
                <button class="button link mr-1" wire:click="up(<?php echo e($widget); ?>)" class="mr-1">
                    <i class="fas fa-arrow-alt-up"></i>
                </button>
                <button class="button link" wire:click="down(<?php echo e($widget); ?>)">
                    <i class="fas fa-arrow-alt-down"></i>
                </button>
            </div>
            <div class="row__column row__column--compact">
                <button class="button link" wire:click="delete(<?php echo e($widget); ?>)">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(!count($widgets)): ?>
        <div class="box__section text-center">There aren't any widgets yet</div>
    <?php endif; ?>
</div>
<?php /**PATH D:\client-project\My\Finanor\resources\views/livewire/widget-list.blade.php ENDPATH**/ ?>