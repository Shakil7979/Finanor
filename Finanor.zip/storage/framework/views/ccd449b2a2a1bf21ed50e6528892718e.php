<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2>Most Expensive Tags</h2>
        <?php if(count($mostExpensiveTags)): ?>
            <div class="box mt-3">
                <?php $__currentLoopData = $mostExpensiveTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box__section row row--seperate">
                        <div class="row__column row__column--middle color-dark">
                            <?php echo $__env->make('partials.tag', ['payload' => $tag], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="row__column row__column--middle">
                            <progress max="<?php echo e($totalSpent); ?>" value="<?php echo e($tag->amount); ?>"></progress>
                        </div>
                        <div class="row__column row__column--middle text-right"><?php echo $currency; ?> <?php echo e(\App\Helper::formatNumber($tag->amount / 100)); ?> / <?php echo $currency; ?> <?php echo e(\App\Helper::formatNumber($totalSpent / 100)); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/reports/most_expensive_tags.blade.php ENDPATH**/ ?>