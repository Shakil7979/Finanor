

<?php $__env->startSection('tailwind', true); ?>

<?php $__env->startSection('title', 'Mail Verification'); ?>

<?php $__env->startSection('body'); ?>
    <div class="max-w-sm mx-auto my-12">
        <img class="h-[150px] mx-auto mb-0 sk_logo" src="/logo.png" alt="App Logo" />

        <div class="p-5 bg-white border rounded-md">

            
            <?php if(session('status')): ?>
                <div class="mb-4 text-sm text-green-600 text-center">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-4 text-sm text-red-600 text-center">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('verification.verify')); ?>">
                <?php echo csrf_field(); ?>
                <h2 class="text-xl font-semibold text-center mb-3 text-gray-800">Verify Your Email</h2>  
                 <p class="mb-3 text-sm text-gray-600">
                    We've sent a verification code to your email. Please enter the code below to verify your account.
                </p>

                <div class="mb-5">
                    <input type="hidden" name="email" value="<?php echo e(old('email')); ?>">
                    <label class="block mb-1 text-sm text-gray-700">Type the code</label>
                    <input
                        type="text"
                        name="code"
                        autocomplete="one-time-code"
                        aria-label="Verification Code"
                        class="w-full px-3 py-2 text-sm border rounded-md"
                    />
                    <?php echo $__env->make('partials.validation_error', ['payload' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div> 

                <button
                    type="submit"
                    class="w-full py-2.5 bg-primary-regular hover:bg-primary-dark transition text-sm text-white rounded-md"
                >
                    Verify
                </button>
            </form>
 
        </div>

        <div class="mt-4 text-center">
            <a class="text-sm transition text-primary-regular hover:text-primary-dark" href="<?php echo e(route('login')); ?>">
                Already using Budget? Log in.
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/mail-verify.blade.php ENDPATH**/ ?>