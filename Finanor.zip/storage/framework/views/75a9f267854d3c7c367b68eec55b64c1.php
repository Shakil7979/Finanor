<?php $__env->startSection('title', __('actions.create') . ' Transaction'); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper mw-400 my-3 sk_dNone">
        <h2 class="mb-3"><?php echo e(__('actions.create')); ?> Transaction</h2>
        <transaction-wizard
            :tags='<?php echo json_encode($tags, 15, 512) ?>'
            :currencies='<?php echo json_encode($currencies, 15, 512) ?>'
            default-transaction-type='<?php echo e($defaultTransactionType); ?>'
            first-day-of-week='<?php echo e($firstDayOfWeek); ?>'
            :default-currency-id='<?php echo e($defaultCurrencyId); ?>'
            :recurrings-intervals='<?php echo json_encode($recurringsIntervals, 15, 512) ?>'
        ></transaction-wizard>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/transactions/create.blade.php ENDPATH**/ ?>