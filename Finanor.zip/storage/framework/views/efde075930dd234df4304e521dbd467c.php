<?php $__env->startSection('settings_title'); ?>
    <h2 class="mb-3"><?php echo e(__('general.preferences')); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body'); ?>
    <div class="box">
        <div class="box__section">
            
            <div class="input input--small">
                <label><?php echo e(__('fields.theme')); ?></label>
                <select name="theme">
                    <option value="light" <?php echo e(Auth::user()->theme == 'light' ? 'selected' : ''); ?>>Light</option>
                    <option value="dark" <?php echo e(Auth::user()->theme == 'dark' ? 'selected' : ''); ?>>Dark (Experimental)</option>
                </select>
                <?php echo $__env->make('partials.validation_error', ['payload' => 'theme'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="input input--small">
                <label><?php echo e(__('fields.weekly_report')); ?></label>
                <div>
                    <input type="radio" name="weekly_report" value="true" <?php echo e(Auth::user()->weekly_report ? 'checked' : ''); ?> /> <?php echo e(__('actions.yes')); ?>

                </div>
                <div>
                    <input type="radio" name="weekly_report" value="false" <?php echo e(Auth::user()->weekly_report ? '' : 'checked'); ?> /> <?php echo e(__('actions.no')); ?>

                </div>
                <?php echo $__env->make('partials.validation_error', ['payload' => 'weekly_report'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="input input--small">
                <label><?php echo e(__('fields.default_transaction_type')); ?></label>
                <div>
                    <input type="radio" name="default_transaction_type" value="earning" <?php echo e(Auth::user()->default_transaction_type === 'earning' ? 'checked' : ''); ?> /> <?php echo e(__('models.earning')); ?>

                </div>
                <div>
                    <input type="radio" name="default_transaction_type" value="spending" <?php echo e(Auth::user()->default_transaction_type === 'spending' ? 'checked' : ''); ?> /> <?php echo e(__('models.spending')); ?>

                </div>
                <?php echo $__env->make('partials.validation_error', ['payload' => 'default_transaction_type'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="input input--small">
                <label><?php echo e(__('fields.first_day_of_week')); ?></label>
                <div>
                    <input type="radio" name="first_day_of_week" value="sunday" <?php echo e(Auth::user()->first_day_of_week === 'sunday' ? 'checked' : ''); ?> /> <?php echo e(__('calendar.weekdays.6')); ?>

                </div>
                <div>
                    <input type="radio" name="first_day_of_week" value="monday" <?php echo e(Auth::user()->first_day_of_week === 'monday' ? 'checked' : ''); ?> /> <?php echo e(__('calendar.weekdays.0')); ?>

                </div>
                <?php echo $__env->make('partials.validation_error', ['payload' => 'first_day_of_week'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <button class="button"><?php echo e(__('actions.save')); ?></button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/settings/preferences.blade.php ENDPATH**/ ?>