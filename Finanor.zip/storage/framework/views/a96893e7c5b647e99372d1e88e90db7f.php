<?php $__env->startSection('title', __('actions.create') . ' Budget'); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper my-3">
        <h2><?php echo e(__('actions.create')); ?> <?php echo e(__('models.budget')); ?></h2>
        <div class="mt-3 box">
            <form method="POST" action="<?php echo e(route('budgets.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="box__section">
                    <?php if(session()->has('message')): ?>
                        <div class="mb-2"><?php echo e(session('message')); ?></div>
                    <?php endif; ?>
                    <div class="input input--small">
                        <label><?php echo e(__('models.tag')); ?></label>
                        <select name="tag_id">
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>" v-pre><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'tag_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small">
                        <label><?php echo e(__('fields.period')); ?></label>
                        <select name="period">
                            <option value="yearly"><?php echo e(__('calendar.intervals.yearly')); ?></option>
                            <option value="monthly" selected><?php echo e(__('calendar.intervals.monthly')); ?></option>
                            <option value="weekly"><?php echo e(__('calendar.intervals.weekly')); ?></option>
                            <option value="daily"><?php echo e(__('calendar.intervals.daily')); ?></option>
                        </select>
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'period'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="input input--small">
                        <label><?php echo e(__('fields.amount')); ?></label>
                        <input type="text" name="amount" />
                        <?php echo $__env->make('partials.validation_error', ['payload' => 'amount'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="box__section box__section--highlight row row--right">
                    <div class="row__column row__column--compact row__column--middle">
                        <a href="<?php echo e(route('budgets.index')); ?>"><?php echo e(__('actions.cancel')); ?></a>
                    </div>
                    <div class="row__column row__column--compact ml-2">
                        <button class="button"><?php echo e(__('actions.create')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/budgets/create.blade.php ENDPATH**/ ?>