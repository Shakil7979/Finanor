<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('body'); ?>
    <div class="wrapper wrapper--narrow my-3">
        <div class="text-center">
            <img src="/logo.svg" style="width: 100%; max-height: 50px;" />
            <h2 class="mt-2 mb-3">Reset Password</h2>
        </div>
        <div class="box">
            <div class="box__section">
                <form method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php if($token): ?>
                        <input type="hidden" name="token" value="<?php echo e($token); ?>" />
                        <div class="input">
                            <label>Password</label>
                            <input type="password" name="password" class="shadow" />
                        </div>
                        <div class="input">
                            <label>Verify Password</label>
                            <input type="password" name="password_confirmation" class="shadow" />
                        </div>
                    <?php else: ?>
                        <div class="input">
                            <label>E-mail</label>
                            <input type="email" name="email" class="shadow" />
                        </div>
                    <?php endif; ?>
                    <button class="button button--wide">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/reset_password.blade.php ENDPATH**/ ?>