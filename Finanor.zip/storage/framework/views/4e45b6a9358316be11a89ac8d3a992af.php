<?php $__env->startSection('settings_title'); ?>
    <h2 class="mb-3"><?php echo e(__('general.dashboard')); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('settings_body_formless'); ?>
    <div class="mb-2">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('widget-wizard', [])->html();
} elseif ($_instance->childHasBeenRendered('o0KqzqC')) {
    $componentId = $_instance->getRenderedChildComponentId('o0KqzqC');
    $componentTag = $_instance->getRenderedChildComponentTagName('o0KqzqC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o0KqzqC');
} else {
    $response = \Livewire\Livewire::mount('widget-wizard', []);
    $html = $response->html();
    $_instance->logRenderedChild('o0KqzqC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('widget-list', [])->html();
} elseif ($_instance->childHasBeenRendered('sPFzVaT')) {
    $componentId = $_instance->getRenderedChildComponentId('sPFzVaT');
    $componentTag = $_instance->getRenderedChildComponentTagName('sPFzVaT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sPFzVaT');
} else {
    $response = \Livewire\Livewire::mount('widget-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('sPFzVaT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\My\Finanor\resources\views/settings/dashboard.blade.php ENDPATH**/ ?>