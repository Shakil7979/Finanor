<?php
return [
    'dashboard' => 'Dashboard',
    'total_spent' => 'Ausgaben Gesamt',
    'most_expensive_tag' => 'Höchste Ausgaben Label',
    'most_expensive_day' => 'Höchste Ausgaben Tag',
    'analysis' => 'Analyse',
    'earnings' => 'Einnahmen',
    'earning' => 'Einnahme',
    'spendings' => 'Ausgaben',
    'spending' => 'Ausgabe',
    'tags' => 'Label',
    'tag' => 'Label',
    'recent' => 'Zuletzt',
    'avatar' => 'Avatar',
    'name' => 'Name',
    'email' => 'E-mail',
    'verify' => 'Bestätigen',
    'password' => 'Passwort',
    'language' => 'Sprache',
    'theme' => 'Design',
    'recurrings' => 'Zyklisch',

    'of' => 'von'
];
