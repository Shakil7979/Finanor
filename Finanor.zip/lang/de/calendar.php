<?php
return [
    'months' => [
        1 => 'Januar',
        2 => 'Februar',
        3 => 'März',
        4 => 'April',
        5 => 'Mai',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'August',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Dezember'
    ],
    'weekdays' => [
        0 => 'Montag',
        1 => 'Dienstag',
        2 => 'Mittwoch',
        3 => 'Donnerstag',
        4 => 'Freitag',
        5 => 'Samstag',
        6 => 'Sonntag'
    ],
    'intervals' => [
        'yearly' => 'Jährlich',
        'monthly' => 'Monatlich',
        'biweekly' => 'Zweiwöchentlich',
        'weekly' => 'Wöchentlich',
        'daily' => 'Täglich'
    ]
];
