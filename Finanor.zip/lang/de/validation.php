
<?php
return [
    'required' => 'Darf nicht leer sein',
    'confirmed' => 'Stimmt nicht überein',
    'max' => [
        'string' => 'Darf nicht länger als :max Zeichen sein'
    ]
];
