
<?php
return [
    'create' => 'Erstellen',
    'edit' => 'Editieren',
    'delete' => 'Löschen'
];
