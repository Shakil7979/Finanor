<?php

return [
    'reports' => 'Rapports',
    'settings' => 'Options',
    'log_out' => 'Déconnexion'
];
