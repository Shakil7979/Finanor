<?php

return [
    'cancel' => 'Annuler',
    'create' => 'Créer',
    'edit' => 'Modifier',
    'save' => 'Sauvegarder',
    'delete' => 'Supprimer',

    'verify' => 'Vérifier',

    'yes' => 'Oui',
    'no' => 'Non'
];
