<?php

return [
    'required' => 'Ne peut pas être vide',
    'confirmed' => 'Ne correspond pas',
    'max' => [
        'string' => 'Ne peut pas être plus long que :max caractères'
    ]
];
