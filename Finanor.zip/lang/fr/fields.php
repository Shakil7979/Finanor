<?php

return [
    'name' => 'Nom',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Mot de passe',
    'language' => 'Langue',
    'theme' => 'Thème',
    'currency' => 'Devise',
    'weekly_report' => 'Rapport Hebdomadaire',
    'default_transaction_type' => 'Type de transaction standard',
    'first_day_of_week' => 'Premier jour de la semaine',

    'period' => 'Période'
];
