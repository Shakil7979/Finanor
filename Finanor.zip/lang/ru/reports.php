<?php

return [
    'weekly_balance' => [
        'title' => 'Еженедельный баланс',
        'description' => 'Еженедельный баланс за год&mdash;отображается в виде графика.'
    ],

    'most_expensive_tags' => [
        'title' => 'Самые дорогие теги',
        'description' => 'Самые дорогие теги за все время&mdash;узнайте, что стоит больше всего.'
    ]
];
