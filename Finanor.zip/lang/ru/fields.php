<?php

return [
    'name' => 'Имя',

    'avatar' => 'Аватар',
    'email' => 'Эл. адрес',
    'password' => 'Пароль',
    'language' => 'Язык',
    'theme' => 'Тема',
    'currency' => 'Валюта',
    'weekly_report' => 'Еженедельный отчет',
    'default_transaction_type' => 'Тип транзакции по умолчанию',
    'first_day_of_week' => 'Воскресенье',

    'date' => 'Дата',
    'description' => 'Описание',
    'amount' => 'Количество',

    'period' => 'Период',

    'file' => 'Файл',

    'color' => 'Цвет',

    'role' => 'Роль'
];
