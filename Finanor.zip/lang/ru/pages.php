<?php

return [
    'reports' => 'Отчеты',
    'settings' => 'Настройки',
    'log_out' => 'Выйти'
];
