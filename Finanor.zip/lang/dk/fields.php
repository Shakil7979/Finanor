<?php

return [
    'name' => 'Navn',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Adgangskode',
    'language' => 'Sprog',
    'theme' => 'Tema',
    'currency' => 'Valuta',
    'weekly_report' => 'Ugentlig Rapport',
    'default_transaction_type' => 'Standard transaktionstype',
    'first_day_of_week' => 'Første dag i ugen',

    'date' => 'Dato',
    'description' => 'Beskrivelse',
    'amount' => 'Beløb',

    'period' => 'Periode',

    'file' => 'Fil'
];
