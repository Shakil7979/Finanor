<?php

return [
    'dashboard' => 'Dashboard',

    'total_earned' => 'Samlet SOMETHING',
    'total_spent' => 'Samlet Beløb For Udgifter',
    'most_expensive_tag' => 'Dyreste Etiket',
    'most_expensive_day' => 'Dyreste Dag',

    'analysis' => 'Analyse',

    'recent' => 'Seneste',

    'profile' => 'Profil',
    'account' => 'Account',
    'preferences' => 'Præferencer',

    'empty_state' => 'Der er endnu ingen :resource',

    'of' => 'af'
];
