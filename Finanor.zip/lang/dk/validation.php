<?php

return [
    'required' => 'Skal være udfyldt',
    'confirmed' => 'Er ikke ens',
    'max' => [
        'string' => 'Kan ikke være længere end :max tegn'
    ]
];
