<?php

return [
    'cancel' => 'Annullere',
    'create' => 'Opret',
    'edit' => 'Redigere',
    'save' => 'Gemme',
    'delete' => 'Slet',

    'verify' => 'Efterprøve',

    'yes' => 'Ja',
    'no' => 'Nej'
];
