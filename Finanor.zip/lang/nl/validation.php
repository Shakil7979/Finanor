<?php

return [
    'required' => 'Kan niet leeg zijn',
    'confirmed' => 'Komt niet overeen',
    'max' => [
        'string' => 'Kan niet langer zijn dan :max karakters'
    ]
];
