<?php

return [
    'name' => 'Naam',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Wachtwoord',
    'language' => 'Taal',
    'theme' => 'Thema',
    'currency' => 'Valuta',
    'weekly_report' => 'Wekelijks Verslag',
    'default_transaction_type' => 'Standaard transactietype',
    'first_day_of_week' => 'Eerste dag van de week',

    'date' => 'Datum',
    'description' => 'Omschrijving',
    'amount' => 'Bedrag',

    'period' => 'Periode',

    'file' => 'Bestand',

    'color' => 'Kleur',

    'role' => 'Rol'
];
