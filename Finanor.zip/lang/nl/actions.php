<?php

return [
    'cancel' => 'Annuleer',
    'create' => 'Creëer',
    'edit' => 'Bewerk',
    'save' => 'Opslaan',
    'delete' => 'Verwijderen',

    'verify' => 'Controleer',

    'yes' => 'Ja',
    'no' => 'Nee',

    'invite' => 'Nodig uit',

    'accept' => 'Accepteer',
    'deny' => 'Weiger'
];
