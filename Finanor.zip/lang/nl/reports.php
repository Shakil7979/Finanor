<?php

return [
    'weekly_balance' => [
        'title' => 'Saldo per Week',
        'description' => 'Wekelijkse saldo per jaar&mdash;weergegeven in een grafiek.'
    ],

    'most_expensive_tags' => [
        'title' => 'Duurste Etiketten',
        'description' => 'De duurste etiketten&mdash;kom erachter wat het meest kost.'
    ]
];
