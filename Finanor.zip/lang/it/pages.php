<?php

return [
    'reports' => 'Resoconti',
    'settings' => 'Impostazioni',
    'log_out' => 'Esci'
];
