<?php

return [
    'required' => 'Non può essere vuoto',
    'confirmed' => 'Non è uguale',

    'max' => [
        'string' => 'Non può essere più lungo di :max caratteri'
    ],

    'forbidden' => 'Non hai il permesso di accedere a questa risorsa'
];
