<?php

return [
    'cancel' => 'Annulla',
    'create' => 'Crea',
    'edit' => 'Modifica',
    'save' => 'Salva',
    'delete' => 'Elimina',

    'verify' => 'Verifica',

    'yes' => 'Sì',
    'no' => 'No',

    'invite' => 'Invita',

    'accept' => 'Accetta',
    'deny' => 'Rifiuta'
];
