<?php

return [
    'budgets' => 'Risparmi',
    'budget' => 'Risparmio',

    'spaces' => 'Spazi',
    'space' => 'Spazio',

    'tags' => 'Categorie',
    'tag' => 'Categoria',

    'recurrings' => 'Transazioni ricorrenti',
    'recurring' => 'Transazione ricorrente',

    'earnings' => 'Entrate',
    'earning' => 'Entrata',

    'spendings' => 'Uscite',
    'spending' => 'Uscita',

    'transactions' => 'Transazioni',
    'transaction' => 'Transazione',

    'imports' => 'Transazioni importate',
    'import' => 'Transazione importata'
];
