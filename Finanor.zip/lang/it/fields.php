<?php

return [
    'name' => 'Nome',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Password',
    'language' => 'Lingua',
    'theme' => 'Tema',
    'currency' => 'Valuta',
    'weekly_report' => 'Report settimanale',
    'default_transaction_type' => 'Tipo di transazione predefinita',
    'first_day_of_week' => 'Primo giorno della settimana',

    'date' => 'Data',
    'description' => 'Descrizione',
    'amount' => 'Importo',

    'period' => 'Periodo',

    'file' => 'File',

    'color' => 'Colore',

    'role' => 'Ruolo'
];
