<?php

return [
    'name' => 'Nome',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Senha',
    'language' => 'Idioma',
    'theme' => 'Tema',
    'currency' => 'Moeda',
    'weekly_report' => 'Relatório Semanal',
    'default_transaction_type' => 'Tipo de transação padrão',
    'first_day_of_week' => 'Primeiro dia da semana',

    'date' => 'Data',
    'description' => 'Descrição',
    'amount' => 'Montante',

    'period' => 'Período',

    'file' => 'Ficheiro'
];
