<?php

return [
    'cancel' => 'Cancelar',
    'create' => 'Criar',
    'edit' => 'Editar',
    'save' => 'Salvar',
    'delete' => 'Deletar',

    'verify' => 'Verificar',

    'yes' => 'Sim',
    'no' => 'Não'
];
