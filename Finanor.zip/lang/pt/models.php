<?php

return [
    'budgets' => 'Orçamentos',
    'budget' => 'Orçamento',

    'spaces' => 'Espaços',
    'space' => 'Espaço',

    'tags' => 'Etiquetas',
    'tag' => 'Etiqueta',

    'recurrings' => 'Recorrências',
    'recurring' => 'Recorrência',

    'earnings' => 'Ganhos',
    'earning' => 'Ganho',

    'spendings' => 'Gastos',
    'spending' => 'Gasto',

    'imports' => 'Importações',
    'import' => 'Importar'
];
