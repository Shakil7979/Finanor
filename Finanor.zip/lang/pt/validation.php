<?php

return [
    'required' => 'Não pode estar em branco',
    'confirmed' => 'Não corresponde',
    'max' => [
        'string' => 'Não pode ser maior que os caracteres máximos'
    ]
];
