<?php

return [
    'cancel' => 'Cancel',
    'create' => 'Create',
    'edit' => 'Edit',
    'save' => 'Save',
    'delete' => 'Delete',

    'verify' => 'Verify',

    'yes' => 'Yes',
    'no' => 'No',

    'invite' => 'Invite',

    'accept' => 'Accept',
    'deny' => 'Deny'
];
