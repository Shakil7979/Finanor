<?php

return [
    'name' => 'Name',

    'avatar' => 'Avatar',
    'email' => 'E-mail',
    'password' => 'Password',
    'language' => 'Language',
    'theme' => 'Theme',
    'currency' => 'Currency',
    'weekly_report' => 'Weekly Report',
    'default_transaction_type' => 'Default transactiontype',
    'first_day_of_week' => 'First day of the week',

    'date' => 'Date',
    'description' => 'Description',
    'amount' => 'Amount',

    'period' => 'Period',

    'file' => 'File',

    'color' => 'Color',

    'role' => 'Role'
];
