<?php

return [
    'budgets' => 'Budgets',
    'budget' => 'Budget',

    'spaces' => 'Spaces',
    'space' => 'Space',

    'tags' => 'Tags',
    'tag' => 'Tag',

    'recurrings' => 'Recurrings',
    'recurring' => 'Recurring',

    'earnings' => 'Earnings',
    'earning' => 'Earning',

    'spendings' => 'Spendings',
    'spending' => 'Spending',

    'transactions' => 'Transactions',
    'transaction' => 'Transaction',

    'imports' => 'Imports',
    'import' => 'Import'
];
