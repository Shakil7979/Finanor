<?php

return [
    'reports' => 'Reports',
    'settings' => 'Settings',
    'log_out' => 'Log Out'
];
