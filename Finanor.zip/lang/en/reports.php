<?php

return [
    'weekly_balance' => [
        'title' => 'Weekly Balance',
        'description' => 'Weekly balance per year&mdash;displayed in a graph.'
    ],

    'most_expensive_tags' => [
        'title' => 'Most Expensive Tags',
        'description' => 'All-time most expensive tags&mdash;find out what costs the most.'
    ]
];
