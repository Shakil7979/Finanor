<?php

return [
    'budgets' => 'Presupuestos',
    'budget' => 'Presupuesto',

    'spaces' => 'Espacios',
    'space' => 'Espacio',

    'tags' => 'Etiquetas',
    'tag' => 'Etiqueta',

    'recurrings' => 'Pagos recurrentes',
    'recurring' => 'Pago recurrente',

    'earnings' => 'Ahorros',
    'earning' => 'Ahorro',

    'spendings' => 'Gastos',
    'spending' => 'Gasto',

    'transactions' => 'Transacciones',
    'transaction' => 'Transacción',

    'imports' => 'Importes',
    'import' => 'Importe'
];
