<?php

return [
    'transaction' => [
        'created' => 'Transacción creada',
        'deleted' => 'Transacción eliminada'
    ],

    'recurring' => [
        'created' => 'Pago recurrente creado',
        'deleted' => 'Pago recurrente eliminado'
    ],

    'tag' => [
        'created' => 'Etiqueta creada',
        'deleted' => 'Etiqueta eliminada'
    ],

    'import' => [
        'created' => 'Importación creada',
        'deleted' => 'Importación eliminada'
    ]
];
