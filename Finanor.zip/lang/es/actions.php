<?php

return [
    'cancel' => 'Cancelar',
    'create' => 'Crear',
    'edit' => 'Editar',
    'save' => 'Guardar',
    'delete' => 'Eliminar',

    'verify' => 'Verificar',

    'yes' => 'Sí',
    'no' => 'No',

    'invite' => 'Invitar',

    'accept' => 'Aceptar',
    'deny' => 'Denegar'
];
