<?php

return [
    'name' => 'Nombre',

    'avatar' => 'Foto de perfil',
    'email' => 'Correo electrónico',
    'password' => 'Contraseña',
    'language' => 'Idioma',
    'theme' => 'Tema',
    'currency' => 'Tipo de moneda',
    'weekly_report' => 'Reporte semanal',
    'default_transaction_type' => 'Tipo de transacción por defecto',
    'first_day_of_week' => 'Primer día de la semana',

    'date' => 'Fecha',
    'description' => 'Descripción',
    'amount' => 'Importe',

    'period' => 'Periodo',

    'file' => 'Archivo',

    'color' => 'Color',

    'role' => 'Rol'
];
