<?php

return [
    'weekly_balance' => [
        'title' => 'Reporte semanal',
        'description' => 'Reporte semanal por año&mdash;Mostrado en un gráfico.'
    ],

    'most_expensive_tags' => [
        'title' => 'Etiquetas con más gastos',
        'description' => 'Las etiquetas con más gastos de todo el tiempo&mdash;descubre dónde gastas más.'
    ]
];
