<?php

return [
    'required' => 'No puede estar en blanco',
    'confirmed' => 'No coincide',

    'max' => [
        'string' => 'No puede superar los :max caracteres'
    ],

    'forbidden' => 'No está permitido el uso de este recurso'
];
