<?php

namespace App\Exceptions;

use Exception;

class WidgetInvalidPropertyValueException extends Exception
{
    //
}
