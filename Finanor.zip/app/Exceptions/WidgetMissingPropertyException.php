<?php

namespace App\Exceptions;

use Exception;

class WidgetMissingPropertyException extends Exception
{
    //
}
