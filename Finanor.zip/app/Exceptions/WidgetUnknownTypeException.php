<?php

namespace App\Exceptions;

use Exception;

class WidgetUnknownTypeException extends Exception
{
    //
}
