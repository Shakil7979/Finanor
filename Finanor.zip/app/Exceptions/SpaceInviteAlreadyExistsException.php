<?php

namespace App\Exceptions;

use Exception;

class SpaceInviteAlreadyExistsException extends Exception
{
    //
}
