<?php

namespace App\Exceptions;

use Exception;

class SpaceInviteInviteeAlreadyPresentException extends Exception
{
    //
}
