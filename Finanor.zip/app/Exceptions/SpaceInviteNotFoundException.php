<?php

namespace App\Exceptions;

use Exception;

class SpaceInviteNotFoundException extends Exception
{
    //
}
