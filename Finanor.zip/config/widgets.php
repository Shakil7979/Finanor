<?php

return [
    'types' => [
        'balance' => [
            'properties' => []
        ],

        'spent' => [
            'properties' => [
                'period' => ['today', 'this_week', 'this_month']
            ]
        ],

        // Any other widgets go here
    ]
];
