<?php return array (
  'widget-list' => 'App\\Http\\Livewire\\WidgetList',
  'widget-wizard' => 'App\\Http\\Livewire\\WidgetWizard',
);