<div class="card card--blue">
    <h2 style="font-size: 20px;">{!! $currencySymbol !!} {{ $balance }}</h2>
    <div class="mt-1">Balance</div> 
</div>
