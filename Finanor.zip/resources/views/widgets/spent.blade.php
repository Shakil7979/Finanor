<div class="card card--red">
    <h2 style="font-size: 20px;">{!! $currencySymbol !!} {{ $spent }}</h2>
    <div class="mt-1">Spent {{ $period }}</div>
</div>
