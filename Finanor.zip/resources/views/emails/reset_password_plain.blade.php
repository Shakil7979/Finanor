Use the link below to reset your password.

{{ config('app.url') }}/reset_password?token={{ $token }}
