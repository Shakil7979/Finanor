Heads up! Your password has been changed ({{ $updated_at }} CEST).
