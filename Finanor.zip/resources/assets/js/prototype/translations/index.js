import * as en from './en.json';
import * as nl from './nl.json';
import * as de from './de.json';
import * as es from './es.json';
import * as ru from './ru.json';

export default {
    en,
    nl,
    de,
    es,
    ru,
};
